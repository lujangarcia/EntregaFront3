# Guía de consignas

En cada uno de los componentes está detallado su funcionamiento.

# Demo del proyecto

Aquí pueden ver una demo del funcionamiento de la aplicación.

![demoReactFE3.gif](https://raw.githubusercontent.com/Frontend-III/entregable-frontend-3-junio22/main/demoReactFE3.gif)
